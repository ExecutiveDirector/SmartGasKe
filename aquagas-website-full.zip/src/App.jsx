import React from 'react';
import AquagasWebsite from './components/AquagasWebsite';
const App = () => <AquagasWebsite />;
export default App;